gstore_v3 README
==================

Getting Started
---------------

- cd <directory containing this file>

- $venv/bin/python setup.py develop

- $venv/bin/populate_gstore_v3 development.ini

- $venv/bin/pserve development.ini

